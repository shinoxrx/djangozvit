from django.contrib import admin
from .models import HorrorMovie, ThrillerMovie, TrueCrimeMovie, ComedyMovie, DetectiveMovie, ActionMovie, AdventureMovie, FantasyMovie

@admin.register(HorrorMovie)
class HorrorMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')


@admin.register(ThrillerMovie)
class ThrillerMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')


@admin.register(TrueCrimeMovie)
class TrueCrimeMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')

@admin.register(ComedyMovie)
class ComedyMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')

@admin.register(DetectiveMovie)
class DetectiveMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')

@admin.register(ActionMovie)
class ActionMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')

@admin.register(AdventureMovie)
class AdventureMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')

@admin.register(FantasyMovie)
class FantasyMovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director', 'rating')
    search_fields = ('title', 'director')

