from django.shortcuts import render
from .models import HorrorMovie, ThrillerMovie, TrueCrimeMovie, ComedyMovie, DetectiveMovie, ActionMovie, AdventureMovie, FantasyMovie

def horror_movies_list(request):
    movies = HorrorMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))
    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/horror.html', context)

def thriller_movies_list(request):
    movies = ThrillerMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))

    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/thriller.html', context)
def truecrime_movies_list(request):
    movies = TrueCrimeMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))

    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/truecrime.html', context)
def comedy_movies_list(request):
    movies = ComedyMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))

    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/comedy.html', context)

def detective_movies_list(request):
    movies = DetectiveMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))

    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/detective.html', context)

def action_movies_list(request):
    movies = ActionMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))

    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/action.html', context)

def adventure_movies_list(request):
    movies = AdventureMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))

    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/adventure.html', context)

def fantasy_movies_list(request):
    movies = FantasyMovie.objects.all()
    rows = list(range(1, 11))
    seats = list(range(1, 16))

    context = {
        'movies': movies,
        'rows': rows,
        'seats': seats,
    }
    return render(request, 'zvit_app/fantasy.html', context)


def home(request):
    return render(request, 'zvit_app/holovna.html')

def horror(request):
    return render(request, 'zvit_app/horror.html')

def thriller(request):
    return render(request, 'zvit_app/thriller.html')

def truecrime(request):
    return render(request, 'zvit_app/truecrime.html')

def comedy(request):
    return render(request, 'zvit_app/comedy.html')

def detective(request):
    return render(request, 'zvit_app/detective.html')

def action(request):
    return render(request, 'zvit_app/action.html')

def adventure(request):
    return render(request, 'zvit_app/adventure.html')

def fantasy(request):
    return render(request, 'zvit_app/fantasy.html')

def holovna(request):
    return render(request, 'holovna.html')


