from django.urls import path
from . import views
from .views import horror_movies_list, thriller_movies_list, truecrime_movies_list, comedy_movies_list, detective_movies_list, action_movies_list, adventure_movies_list, fantasy_movies_list

urlpatterns = [
    path('', views.home, name='home'),
    path('holovna.html', views.home, name='home'),
    path('thriller.html/', thriller_movies_list, name='thriller_movie_list'),
    path('truecrime.html/', truecrime_movies_list, name='truecrime_movies_list'),
    path('comedy.html/', comedy_movies_list, name='comedy_movies_list'),
    path('detective.html/', detective_movies_list, name='detective'),
    path('action.html/', action_movies_list, name='action'),
    path('adventure.html/', adventure_movies_list, name='adventure'),
    path('fantasy.html/', fantasy_movies_list, name='fantasy'),
    path('horror.html/', horror_movies_list, name='horror_movies_list'),
]
