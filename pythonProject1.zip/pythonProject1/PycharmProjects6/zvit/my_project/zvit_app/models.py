from django.db import models

class HorrorMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title


class ThrillerMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title

class TrueCrimeMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title

class ComedyMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title

class AdventureMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title


class ActionMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title


class DetectiveMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title

class FantasyMovie(models.Model):
    title = models.CharField(max_length=255)
    year = models.IntegerField()
    director = models.CharField(max_length=255)
    poster = models.URLField(max_length=500, blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    def __str__(self):
        return self.title