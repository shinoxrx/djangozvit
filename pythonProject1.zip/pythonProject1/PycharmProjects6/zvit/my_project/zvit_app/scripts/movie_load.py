import csv
from zvit_app.models import HorrorMovie, ThrillerMovie, TrueCrimeMovie, ComedyMovie, ActionMovie, AdventureMovie, FantasyMovie, DetectiveMovie

def run():
    with open('zvit_app/scripts/horror.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            horror = HorrorMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster'),
                rating=row.get('Rating') or None
            )
            horror.save()
            print(row['Title'], row['Year'], row['Director'], row.get('Poster'))


def import_thriller_movies():
    with open('zvit_app/scripts/thriller.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            thriller_movie = ThrillerMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster') or '',
                rating=row.get('Rating') or None
            )
            thriller_movie.save()
            print(f"Saved: {thriller_movie.title}")



def import_truecrime_movies():
    with open('zvit_app/scripts/truecrime.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            truecrime_movie = TrueCrimeMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster') or '',
                rating=row.get('Rating') or None
            )
            truecrime_movie.save()
            print(f"Saved: {truecrime_movie.title}")


def import_comedy_movies():
    with open('zvit_app/scripts/comedy.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            comedy_movie = ComedyMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster') or '',
                rating=float(row['Rating']) if row['Rating'] else None
            )
            comedy_movie.save()
            print(f"Saved: {comedy_movie.title}")


def import_detective_movies():
    with open('zvit_app/scripts/detective.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            detective_movie = DetectiveMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster') or '',
                rating=float(row['Rating']) if row['Rating'] else None
            )
            detective_movie.save()
            print(f"Saved: {detective_movie.title}")


def import_action_movies():
    with open('zvit_app/scripts/action.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            action_movie = ActionMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster') or '',
                rating=float(row['Rating']) if row['Rating'] else None
            )
            action_movie.save()
            print(f"Saved: {action_movie.title}")


def import_adventure_movies():
    with open('zvit_app/scripts/adventure.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            adventure_movie = AdventureMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster') or '',
                rating=float(row['Rating']) if row['Rating'] else None
            )
            adventure_movie.save()
            print(f"Saved: {adventure_movie.title}")



def import_fantasy_movies():
    with open('zvit_app/scripts/fantasy.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            fantasy_movie = FantasyMovie(
                title=row['Title'],
                year=row['Year'],
                director=row['Director'],
                poster=row.get('Poster') or '',
                rating=float(row['Rating']) if row['Rating'] else None
            )
            fantasy_movie.save()
            print(f"Saved: {fantasy_movie.title}")