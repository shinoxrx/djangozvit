from django.apps import AppConfig


class GuessGameConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'guess_game'
